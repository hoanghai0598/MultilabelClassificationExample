# Python code to
# demonstrate readlines()
import joblib

file = open('file.txt', 'r')

Lines = file.readlines()

count = 0

for line in Lines:
    print("Line{}: {}".format(count, line.strip()))

filename = 'svm_model.json'
loaded_model = joblib.load(filename)